from misc import print, args, setfoldericon
import os, sys
from pathlib import Path


# cd c:\users\user & pyinstaller --noconfirm --onefile --console --icon "C:\Users\User\Desktop\file sorter\icons\icon.ico"  "C:\Users\User\Desktop\file sorter\setfoldericon.py"
# cd c:\users\user ; pyinstaller --noconfirm --onefile --console --icon "C:\Users\User\Desktop\file sorter\icons\icon.ico"  "C:\Users\User\Desktop\file sorter\setfoldericon.py"
def sfi():
    args.parse()
    args.setalias(
        {
            "cmds": ["path", "p", "dir", "d"],
            "help": "Path to the folder to change the icon of",
            "type": "dir",
        },
        {
            "cmds": ["icon", "i", "file"],
            "help": "Path to the icon file, leave blank to clear icon",
            "type": "file",
        },
    )


    def getimg(path, dir):
        if not path.endswith(".ico"):
            path = path + ".ico"
        if Path(os.path.abspath(path)).is_file():
            return os.path.abspath(path)
        if Path(os.path.abspath(os.path.join(dir, path))).is_file():
            return os.path.abspath(os.path.join(dir, path))
        return False


    if not args.has("p"):
        print.error(
            "No path specified! Please specify a path to the folder you want to add an icon to."
        )
        sys.exit(-1)
    if args.has("i"):
        for path in args.get("p"):
            icon = args.get("i")[0]
            img = getimg(icon, path)
            if not img:
                print.error(f'"{os.path.abspath(icon)}" is not a file')
            if setfoldericon(path, img):
                print.sucess(f'icon updated for "{path}"')

    else:
        for path in args.get("p"):
            path = os.path.abspath(path)
            if Path(os.path.join(path, "desktop.ini")).exists():
                os.remove(os.path.join(path, "desktop.ini"))
            else:
                print.error(f'"{path}" has no icon')
            if Path(os.path.join(path, "foldericon.ico")).exists():
                os.remove(os.path.join(path, "foldericon.ico"))
            else:
                print.error(f'"{path}" has no icon')
            os.system('attrib -r "%s"' % str(path))
            print.sucess(f'icon removed for "{path}"')
    return 0